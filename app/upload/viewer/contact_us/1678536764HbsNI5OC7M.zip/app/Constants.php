<?php

const SUCCESS = 1;
const ERROR = 0;

