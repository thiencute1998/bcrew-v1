@extends('viewer.layouts.master')
@section('viewer-content')
    <div id="content" role="main" class="content-area">
        <!--<div class="img has-hover ipixal_htw_block1 x md-x lg-x y md-y lg-y" id="image_1100296472">
            <div class="img-inner dark">
                <img width="1020" height="322" src="https://specialediting.org/wp-content/uploads/2022/05/how_to_work-1400x442.webp" class="attachment-large size-large" alt="" decoding="async" loading="lazy" srcset="https://specialediting.org/wp-content/uploads/2022/05/how_to_work-1400x442.webp 1400w, https://specialediting.org/wp-content/uploads/2022/05/how_to_work-800x253.webp 800w, https://specialediting.org/wp-content/uploads/2022/05/how_to_work-768x242.webp 768w, https://specialediting.org/wp-content/uploads/2022/05/how_to_work-1536x485.webp 1536w, https://specialediting.org/wp-content/uploads/2022/05/how_to_work-600x189.webp 600w, https://specialediting.org/wp-content/uploads/2022/05/how_to_work.webp 1920w" sizes="(max-width: 1020px) 100vw, 1020px">
        </div>
    <style>
    #image_1100296472 {
      width: 100%;
    }
    </style>
        </div>-->
        <div id="text-3637920921" class="text ipixal_htw_block2">
            <h2 class="only-step aos-init aos-animate" data-aos="fade-down">ONLY 4 EASY STEPS</h2>

            <style>
                #text-3637920921 {
                    text-align: center;
                }
            </style>
        </div>

        <div class="row ipixal_htw_block3" id="row-1527436593">
            <div id="col-545923776" class="col small-12 large-12">
                <div class="col-inner">
                    <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_1243734441">
                        <div class="img-inner dark">
                            <img width="1020" height="620"
                                 src="https://specialediting.org/wp-content/uploads/2022/05/4step.png"
                                 class="attachment-large size-large" alt="" decoding="async" loading="lazy"
                                 srcset="https://specialediting.org/wp-content/uploads/2022/05/4step.png 1070w, https://specialediting.org/wp-content/uploads/2022/05/4step-658x400.png 658w, https://specialediting.org/wp-content/uploads/2022/05/4step-768x467.png 768w, https://specialediting.org/wp-content/uploads/2022/05/4step-600x364.png 600w"
                                 sizes="(max-width: 1020px) 100vw, 1020px">
                        </div>

                        <style>
                            #image_1243734441 {
                                width: 100%;
                            }
                        </style>
                    </div>

                </div>
            </div>

        </div>


    </div>
@endsection
